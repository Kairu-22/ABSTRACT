from title_keyword import *
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

DEVELOPER_KEY = "AIzaSyAAmoO_fdKUJ3SHuv2EysnNcrtTp-PaRfw"
YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"
videos = []
def youtube_search(query,videos):
    youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
                    developerKey=DEVELOPER_KEY)

    # Call the search.list method to retrieve results matching the specified
    # query term.
    search_response = youtube.search().list(
        q=query,
        type='video',
        part='id,snippet',
        maxResults=5,
        order='viewCount'
    ).execute()

    

    # Add each result to the appropriate list
    for search_result in search_response.get("items", []):
        if search_result["id"]["kind"] == "youtube#video":
            videos.append("%s (%s)" % (search_result["snippet"]["title"],
                                       search_result["id"]["videoId"]))

    #print("Videos:\n", "\n".join(videos), "\n")

try:
    for i in a:
        youtube_search(i,videos)
except HttpError as e:
    print("An HTTP error %d occurred:\n%s" % (e.resp.status, e.content))

