from tags import *
from tagslist import *
#update
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


creds = Credentials.from_authorized_user_info(info={
    'client_id': "AIzaSyAAmoO_fdKUJ3SHuv2EysnNcrtTp-PaRfw",
    'client_secret': 'YOUR_CLIENT_SECRET',
    'refresh_token': 'YOUR_REFRESH_TOKEN',
})

YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"

def update_video_description(video_id, description):
    youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
                    credentials=creds)

    # Call the videos.update method to update the video's metadata
    youtube.videos().update(
        part='snippet',
        body={
            'id': video_id,
            'snippet': {
                'description': description
            }
        }
    ).execute()

try:
    update_video_description("YOUR_VIDEO_ID", "YOUR_UPDATED_DESCRIPTION")
except HttpError as e:
    print("An HTTP error %d occurred:\n%s" % (e.resp.status, e.content))
