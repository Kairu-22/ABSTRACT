from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

DEVELOPER_KEY = "AIzaSyAAmoO_fdKUJ3SHuv2EysnNcrtTp-PaRfw"
YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"

def get_video_title(video_id):
    youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
                    developerKey=DEVELOPER_KEY)

    # Call the videos.list method to retrieve information about the video
    video_response = youtube.videos().list(
        id=video_id,
        part='snippet'
    ).execute()

    video_title = video_response['items'][0]['snippet']['title']

    return video_title
'''
try:
    print(get_video_title("8nOd45wX2nE"))
except HttpError as e:
    print("An HTTP error %d occurred:\n%s" % (e.resp.status, e.content))
'''
