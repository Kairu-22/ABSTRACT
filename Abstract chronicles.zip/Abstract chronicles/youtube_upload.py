import os
import datetime
import google.auth
import googleapiclient
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.oauth2.credentials import Credentials
import time
import google_auth_oauthlib
from google.auth.transport.requests import Request

# Authenticate with Google API
creds = None
if os.path.exists('token.json'):
    creds = Credentials.from_authorized_user_file('token.json')
if not creds or not creds.valid:
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    else:
        flow = google_auth_oauthlib.flow.InstalledAppFlow.from_client_secrets_file(
            'client_secret.json', scopes=['https://www.googleapis.com/auth/youtube.upload'])
        creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

# Set video details
title = "My Video Title"
description = "My Video Description"
file_path = "D:/compbackup/videos/video_20181227_120704.mp4"
tags = ["tag1", "tag2", "tag3"]
thumbnail_path = "D:/compbackup/z/202.jpg"
privacy = "unlisted"
comments_enabled = False
upload_date_time = datetime.datetime(2023, 4, 18, 12, 20)  # set the date and time for uploading the video

# Set YouTube API client
youtube = build('youtube', 'v3', credentials=creds)

# Prepare the video resource
body = {
    'snippet': {
        'title': title,
        'description': description,
        'tags': tags,
        'categoryId': '22'
    },
    'status': {
        'privacyStatus': privacy,
        'selfDeclaredMadeForKids': False,
        'embeddable': True,
        'license': 'youtube',
        'publicStatsViewable': True,
        'madeForKids': False,
        'comments': {'moderationStatus': 'heldForReview' if comments_enabled else 'closed'}
    }
}

# Prepare the media object for the video upload
media = googleapiclient.http.MediaFileUpload(file_path)

# Upload the video
try:
    response = youtube.videos().insert(
        part='snippet,status',
        body=body,
        media_body=media,
        notifySubscribers=True
    ).execute()
    print(f"Video id '{response['id']}' was successfully uploaded to YouTube!")
except HttpError as error:
    print(f"An error occurred: {error}")
    response = None

# Set thumbnail image for the uploaded video
if response is not None and thumbnail_path is not None:
    youtube.thumbnails().set(
        videoId=response['id'],
        media_body=googleapiclient.http.MediaFileUpload(thumbnail_path)
    ).execute()

# Set privacy settings for the uploaded video
if response is not None and privacy is not None:
    youtube.videos().update(
        part='status',
        body={
            'id': response['id'],
            'status': {
                'privacyStatus': privacy
            }
        }
    ).execute()

# Set comment settings for the uploaded video
if response is not None and comments_enabled is not None:
    youtube.videos().update(
        part='snippet',
        body={
            'id': response['id'],
            'snippet': {
                'title': title,
                'description': description,
                'tags': tags,
                'categoryId': '22'
            }
        },
    
            status = "Success" if response['id'] else "Failed",
            comment = "Video uploaded successfully to YouTube" if response['id'] else f"Upload failed: {response}"
    )
print("Success????")