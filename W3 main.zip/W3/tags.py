#tags
import YoutubeTags
from YoutubeTags import videotags

link = "https://youtu.be/8nOd45wX2nE"
#https://www.youtube.com/watch?v=QEtjob__Fc0"
#https://www.youtube.com/watch?v=qV7BPfHbYIQ" # Use https / http Links
at = videotags(link)
#print(at)
#print(type(at))
at=at.split(', ')
#print(at)
