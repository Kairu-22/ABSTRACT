#title_keyword
from title import *
import nltk
#nltk.download('stopwords')
#nltk.download('punkt')
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize


try:
    title=get_video_title("8nOd45wX2nE")
except HttpError as e:
    print("An HTTP error %d occurred:\n%s" % (e.resp.status, e.content))



    

#title = "How to extract keywords from youtube video title"
stop_words = set(stopwords.words('english'))

# Tokenize the title into individual words
word_tokens = word_tokenize(title)

# Remove stop words and punctuation
filtered_title = [word for word in word_tokens if word.isalnum() and word.lower() not in stop_words]

print(filtered_title)



from nltk import bigrams


#text = "This is an example sentence."
#tokens = word_tokenize(text)
#print(tokens)
# Generate bigrams


from nltk import trigrams




# Generate trigrams
trigram_list = list(trigrams(filtered_title))
a=[]
for i in trigram_list:
    a.append(' '.join(i))
#print(trigram_list)

bigram_list = list(bigrams(filtered_title))
for i in bigram_list:
    a.append(' '.join(i))

#print(bigram_list)
print(a)
